# Python Program to calculate the square root

def cube_root(number):
	num_sqrt = 0
	for i in range(number):
		num_sqrt = i ** 0.3333
	return num_sqrt