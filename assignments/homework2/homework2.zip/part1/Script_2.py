# Python script

def mult_by_twoPower(number):
	num = 0
	for i in range(number):
		num = i * 2 ** i
	return num