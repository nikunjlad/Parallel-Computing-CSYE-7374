# This is python program

def sum_cube(number):
	s = 0
	for i in range(number):
		s += i*i*i
	return s